import LandingPage from "@/components/layouts/LandingPage";
import LoginPage from "@/components/layouts/LoginPage";
import Image from "next/image";

export default function Home() {
  return (
    <div>
      <LandingPage />
    </div>
  );
}
