
const Cases = () => {
  return (
    <div>Cases</div>
  )
}

export default Cases